Copie des fichiers de sauvegardes dans l'EC2 + connexion :
```bash
scp -i "shop.pem" catalogue-db.sql ec2-user@13.37.249.179:~/catalogue-db.sql
scp -i "shop.pem" databases.tar ec2-user@13.36.38.235:~/databases.tar
ssh -i "shop.pem" ec2-user@13.37.249.179
```

__Dans l'EC2 : Récup le certificat DocumentDB AWS
```bash
wget https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem
```
# MySQL
__INSTALLATIONS :
```bash
sudo yum update
```
__MySQL :
```bash
sudo dnf install -y httpd mariadb105²² wget php-fpm php-mysqli php-json php php-devel
systemctl start mysqld
sudo systemctl enable mysqld
sudo mysql_secure_installation
sudo systemctl status mysqld
```
__Connexion MySQL:
```txt
mysql -h endpoint -P 3306 -u admin –p
CREATE USER 'maikiboss'@'%';
CREATE DATABASE sockshop;
GRANT ALL PRIVILEGES ON sockshop.* TO 'maikiboss'@'%';
FLUSH PRIVILEGES;
EXIT;
```

__IMPORT BDD dans MySQL : Une fois connecté dans MySQL :
```bash
mysql> source catalogue-db.sql;
OU 
Depuis l'EC2 :
mysql -h endpoint -P 3306 -u maikiboss –ppassword sockshop < catalogue_db.sql
```

# DOCUMENTDB
__INSTALLATIONS :
```bash
sudo vim /etc/yum.repos.d/mongodb-org-7.0.repo
```
```txt
[mongodb-org-7.0]
name=MongoDB Repository
baseurl=https://repo.mongodb.org/yum/amazon/2023/mongodb-org/7.0/x86_64/
gpgcheck=1
enabled=1
gpgkey=https://pgp.mongodb.com/server-7.0.asc
```
```bash
sudo yum install -y mongodb-org
sudo yum list installed mongodb-database-tools
sudo systemctl start mongod
sudo systemctl daemon-reload
sudo systemctl enable mongod
sudo systemctl status mongod
```
---------- sur un EC2 ubuntu : 
```bash
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add - sudo apt-get install gnupg 
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list 
sudo apt-get update sudo apt-get install -y mongodb-org 
sudo systemctl start mongod 
sudo systemctl daemon-reload 
sudo systemctl status mongod
```

__CF DOC :
```bash
mongoimport --ssl \ 
    --host="tutorialCluster.amazonaws.com:27017" \ 
    --collection=restaurants \
    --db=business \ 
    --file=restaurant.json \
    --numInsertionWorkers 4 \
    --username=maikiboss \
    --password=password \
    --sslCAFile global-bundle.pem
__IMPORT BDD DocumentDB
```
1/ DB CARTS
```bash
mongoimport --ssl \
     --host sock-shop-docdb-test-db-docdb.cluster-cbgy0ouc03so.eu-west-3.docdb.amazonaws.com:27017 \
     --collection=carts-db \
     --db=carts \
     --numInsertionWorkers 2 \
     --file="/home/ec2-user/databases-sauvegardes/carts-db/system.version.metadata.json" \
     --sslCAFile "/home/ec2-user/databases-sauvegardes/global-bundle.pem" \
     --username="maikiboss" \
     --password="password"
```

2/ DB ORDERS
```bash
mongoimport --ssl \
     --host sock-shop-docdb-test-db-docdb.cluster-cbgy0ouc03so.eu-west-3.docdb.amazonaws.com:27017 \
     --collection=orders-db \
     --db=orders \
     --numInsertionWorkers 2 \
     --file="/home/ec2-user/databases-sauvegardes/orders-db/system.version.metadata.json" \
     --sslCAFile "/home/ec2-user/databases-sauvegardes/global-bundle.pem" \
     --username="maikiboss" \
     --password="password"
```

3/ DB USERS
```bash
mongoimport --ssl \
     --host sock-shop-docdb-test-db-docdb.cluster-cbgy0ouc03so.eu-west-3.docdb.amazonaws.com:27017 \
     --collection=users-db \
     --db=addresses \
     --numInsertionWorkers 2 \
     --file="/home/ec2-user/databases-sauvegardes/users-db/addresses.metadata.json" \
     --sslCAFile "/home/ec2-user/databases-sauvegardes/global-bundle.pem" \
     --username="maikiboss" \
     --password="password"

mongoimport --ssl \
     --host sock-shop-docdb-test-db-docdb.cluster-cbgy0ouc03so.eu-west-3.docdb.amazonaws.com:27017 \
     --collection=users-db \
     --db=cards \
     --numInsertionWorkers 2 \
     --file="/home/ec2-user/databases-sauvegardes/users-db/cards.metadata.json" \
     --sslCAFile "/home/ec2-user/databases-sauvegardes/global-bundle.pem" \
     --username="maikiboss" \
     --password="password"

mongoimport --ssl \
     --host sock-shop-docdb-test-db-docdb.cluster-cbgy0ouc03so.eu-west-3.docdb.amazonaws.com:27017 \
     --collection=users-db \
     --db=customers \
     --numInsertionWorkers 2 \
     --file="/home/ec2-user/databases-sauvegardes/users-db/customers.metadata.json" \
     --sslCAFile "/home/ec2-user/databases-sauvegardes/global-bundle.pem" \
     --username="maikiboss" \
     --password="password"
```